import os
cwd = os.getcwd()

rawdata_dump = cwd + "\\static\\raw_data\\rawData.xlsx"
images_folder = cwd + "\\static\\images\\"
cols_of_interest = ['Short Description', 'Category', 'Assignment Group', 'Cause Code', 'Description', 'Close Notes', 'Close Code']
filter_rows_dict = {'Category': [], 'Cause Code': []}
word_cloud_columns = ['Short Description', 'Close Notes']
new_stopwords = ["january", "february", "march", "april", "may", "june", "july", "august", \
                 "september", "october", "november", "december", "monday", "tuesday", "wednesday", "thursday", \
                 "friday", "saturday"]
