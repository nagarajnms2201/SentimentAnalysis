import pandas as pd
import config
import os
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from flask import Flask, request, render_template

file = config.rawdata_dump
excel_df = pd.read_excel(file)
cols_of_interest = config.cols_of_interest
excel_df = excel_df[cols_of_interest]

app = Flask(__name__)


def filter_rows(excel_df, filter_rows):
    '''
    This methods filters the excel for the selected Categories and Cause Codes.
    '''
    for key, value in filter_rows.items():
        if len(value) > 0:
            excel_df = excel_df[excel_df[key].isin(value)]
    return excel_df


def clean_images_folder():
    '''
    This method checks if there are any existing images in the images_folder
    and deletes them.
    '''
    images_folder = config.images_folder
    for file in os.listdir(images_folder):
        file_path = os.path.join(images_folder, file)
        try:
            if os.path.isfile(file_path):
                print("Deleting {}".format(file))
                os.unlink(file_path)
        except Exception as e:
            print(e)


def draw_word_cloud(column, filtered_string):
    """
    This method takes the filtered string (Important Words) as input and creates a
    word cloud for the same and saves the image.
    """
    wordcloud = WordCloud(width=800, height=800,
                          background_color='white',
                          min_font_size=10).generate(filtered_string)
    images_folder = config.images_folder

    # plot the WordCloud image
    plt.figure(figsize=(8, 8), facecolor=None)
    plt.imshow(wordcloud)
    plt.axis("off")
    # plt.title('Word cloud of ' + column)
    plt.savefig(images_folder + column + '.png')
    plt.tight_layout(pad=0)
    plt.close
    print("The word cloud {}.png is created".format(column))


def filter_imp_words_per_column(data_frame):
    """
    This method filters the important words for the column dumps of the interested columns
    and then calls the 'draw_word_cloud' by passing the column name name and the filtered
    string as inputs.
    """
    clean_images_folder()
    for arg in config.word_cloud_columns:
        column = str(arg).replace(' ', '_')
        column_dump = str(data_frame[arg])
        tokenized_word = word_tokenize(column_dump)
        filtered_words_in_column = [
            word.replace('/', '').replace('@', '').replace('\\|', '').lower()
            for word in tokenized_word if not (word.isdigit())]

        stop_words = stopwords.words('english')
        new_stopwords = config.new_stopwords
        stop_words.extend(new_stopwords)
        filtered_imp_words_per_column = [
            word for word in filtered_words_in_column if word not in stop_words]
        final_filtered_str = ''
        for word in filtered_imp_words_per_column:
            final_filtered_str += word + ' '
        draw_word_cloud(column, final_filtered_str)


@app.route('/sentiment')
def sentiment_analysis():
    '''
    This method is called from the frontend and the Category and Cause Codes
    columns are filtered for unique values and populated in the frontend.
    '''
    global excel_df
    cat_list = excel_df['Category'].unique().tolist()
    cause_code_list = excel_df['Cause Code'].unique().tolist()
    cause_code_clean_list = [item for item in cause_code_list if str(item) != 'nan']
    return render_template('index.html', cat_list=cat_list, cc_list=cause_code_clean_list)


@app.route('/update', methods=['POST', 'GET'])
def update_config_files():
    '''
    This method is called on Submission of the Sentiment request Form from the
    frontend. The form is parsed for the necessary Categories and Cause Codes and
    the rows are filtered accordingly by calling the 'filter_rows' method
    The Word Clouds are then created by calling the 'filter_imp_words_per_column'
    method and the word cloud page is then rendered.
    '''
    global excel_df
    filter_rows_dict = config.filter_rows_dict
    category_list = []
    cause_code_list = []

    data = request.form.to_dict()
    for key in data:
        if key.startswith('cat_') and key != 'cat_nan':
            category_list.append(key.replace('cat_', ''))
        elif key.startswith('cc_') and key != 'cc_nan':
            cause_code_list.append(key.replace('cc_', ''))

    filter_rows_dict['Category'] = category_list
    filter_rows_dict['Cause Code'] = cause_code_list

    filtered_excel_df = filter_rows(excel_df, filter_rows_dict)
    print("The number of records filtered are {}".format(filtered_excel_df.shape[0]))
    filter_imp_words_per_column(filtered_excel_df)
    return render_template('output.html', rows=filtered_excel_df.shape[0])


if __name__ == '__main__':
    app.run(debug=True, port=9999)
